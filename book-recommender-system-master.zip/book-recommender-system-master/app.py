from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__)

# Load data
popular_df = pickle.load(open('popular.pkl', 'rb'))
pt = pickle.load(open('pt.pkl', 'rb'))
books = pickle.load(open('books.pkl', 'rb'))
similarity_scores = pickle.load(open('similarity_scores.pkl', 'rb'))

@app.route('/')
def index():
    book_data = [
        {
            'book_name': name,
            'author': author,
            'image': image,
            'votes': votes,
            'rating': rating
        }
        for name, author, image, votes, rating in zip(
            popular_df['Book-Title'].values,
            popular_df['Book-Author'].values,
            popular_df['Image-URL-M'].values,
            popular_df['num_ratings'].values,
            popular_df['avg_rating'].values
        )
    ]
    return render_template('index.html', books=book_data)

@app.route('/recommend')
def recommend_ui():
    return render_template('recommend.html', data=None)

@app.route('/recommend_books', methods=['POST'])
def recommend():
    user_input = request.form.get('user_input')
    index = np.where(pt.index == user_input)[0]

    if len(index) == 0:
        # Handle the case when the user input is not found
        return render_template('recommend.html', data=None)

    index = index[0]
    similar_items = sorted(list(enumerate(similarity_scores[index])), key=lambda x: x[1], reverse=True)[1:5]

    data = [
        {
            'title': pt.index[i[0]],
            'author': books[books['Book-Title'] == pt.index[i[0]]].iloc[0]['Book-Author'],
            'image': books[books['Book-Title'] == pt.index[i[0]]].iloc[0]['Image-URL-M'],
        }
        for i in similar_items
    ]

    return render_template('recommend.html', data=data)

if __name__ == '__main__':
    app.run(debug=True)
